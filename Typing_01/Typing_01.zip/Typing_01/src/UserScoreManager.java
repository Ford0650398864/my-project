/*import java.util.HashMap;

public class UserScoreManager {
    private HashMap<String, Integer> userScores;

    public UserScoreManager() {
        userScores = new HashMap<>();
    }

    public void addUserScore(String username, int score) {
        userScores.put(username, score);
    }

    public int getUserScore(String username) {
        return userScores.getOrDefault(username, 0);
    }

    public void displayUserScores() {
        System.out.println("User Scores:");
        for (String username : userScores.keySet()) {
            int score = userScores.get(username);
            System.out.println(username + ": " + score);
        }
    }
}*/
